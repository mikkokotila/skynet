#!/bin/bash 

./bin/cms-build.sh
